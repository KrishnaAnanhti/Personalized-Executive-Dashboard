package com.unisys.Rekognition;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.nio.ByteBuffer;
import java.util.List;

import javax.imageio.ImageIO;

import com.amazonaws.AmazonClientException;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.rekognition.AmazonRekognition;
import com.amazonaws.services.rekognition.AmazonRekognitionClientBuilder;
import com.amazonaws.services.rekognition.model.BoundingBox;
import com.amazonaws.services.rekognition.model.CompareFacesMatch;
import com.amazonaws.services.rekognition.model.CompareFacesRequest;
import com.amazonaws.services.rekognition.model.CompareFacesResult;
import com.amazonaws.services.rekognition.model.ComparedFace;
import com.amazonaws.services.rekognition.model.Image;
import com.amazonaws.services.rekognition.model.S3Object;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.ListObjectsRequest;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.S3ObjectSummary; 

public class LocalImageByte {
	public static final String S3_BUCKET = "rekognition-face-comparsion";

	public static void main(String[] args) throws Exception {
		///byte[] bytes = IOUtils.toByteArray(is);
		
		//AmazonS3 s3client = new AmazonS3Client(new ProfileCredentialsProvider());

		AmazonS3 s3client = new AmazonS3Client(new ProfileCredentialsProvider("default").getCredentials());
	/*	int bytes = b.getByteCount();
		//or we can calculate bytes this way. Use a different value than 4 if you don't use 32bit images.
		//int bytes = b.getWidth()*b.getHeight()*4; 

		ByteBuffer buffer = ByteBuffer.allocate(bytes); //Create a new buffer
		b.copyPixelsToBuffer(buffer); //Move the byte data to the buffer
		byte[] array = buffer.array();*/
		
		File fnew = new File("D:/aPaaS/Aws/Rek Demo/images/sindhu1.jpg");
		BufferedImage originalImage = ImageIO.read(fnew);
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ImageIO.write(originalImage, "jpg", baos);
	//	String baosStr=baos.toString();
		//System.out.println("str"+baosStr);
		//byte[] imageInByte = org.apache.commons.codec.binary.Base64.decodeBase64(baosStr.getBytes()); 
		
		byte[] imageInByte = baos.toByteArray();
		ByteBuffer buf = ByteBuffer.wrap(imageInByte);
		System.out.println("byteArr"+imageInByte);

		Image source = getImageUtilWithBytes(buf);

		ListObjectsRequest listObjectsRequest = new ListObjectsRequest().withBucketName(S3_BUCKET);
		System.out.println("testing");
		ObjectListing objectListing;
		String matchedImage = "", returnedImage;
		do {
			objectListing = s3client.listObjects(listObjectsRequest);
			for (S3ObjectSummary objectSummary : objectListing.getObjectSummaries()) {
				// System.out.println(" - " + objectSummary.getKey() + " " +
				// "(size = " + objectSummary.getSize() + ")");
				returnedImage = CompareAllFaces(source, objectSummary.getKey()); 
				if (null != returnedImage)
					matchedImage = returnedImage;
			}
			listObjectsRequest.setMarker(objectListing.getNextMarker());
		} while (objectListing.isTruncated());
		System.out.println("matchedImage" + matchedImage);
	}

	private static String CompareAllFaces(Image source, String targ) {
		AWSCredentials credentials;
		try {
			credentials = new ProfileCredentialsProvider("default").getCredentials();
		} catch (Exception e) {
			throw new AmazonClientException("Cannot load the credentials from the credential profiles file. "
					+ "Please make sure that your credentials file is at the correct "
					+ "location (/Users/userid/.aws/credentials), and is in valid format.", e);
		}

		Image target = getImageUtil(S3_BUCKET, targ);
		Float similarityThreshold = 70F;
		AmazonRekognition rekognitionClient = AmazonRekognitionClientBuilder.standard().withRegion(Regions.US_EAST_1)
				.withCredentials(new AWSStaticCredentialsProvider(credentials)).build();
		CompareFacesResult compareFacesResult = callCompareFaces(source, target, similarityThreshold,
				rekognitionClient);

		List<CompareFacesMatch> faceDetails = compareFacesResult.getFaceMatches();
		if (faceDetails.size() == 0)
			System.out.println("No match" + source + targ);
		for (CompareFacesMatch match : faceDetails) {
			ComparedFace face = match.getFace();
			BoundingBox position = face.getBoundingBox();
			System.out.println(source + targ + "Face at " + position.getLeft().toString() + " " + position.getTop()
					+ " matches with " + face.getConfidence().toString() + "% confidence.");
			return position.getLeft().toString();
		}
		return null;
	}

	private static CompareFacesResult callCompareFaces(Image sourceImage, Image targetImage, Float similarityThreshold,
			AmazonRekognition amazonRekognition) {

		CompareFacesRequest compareFacesRequest = new CompareFacesRequest().withSourceImage(sourceImage)
				.withTargetImage(targetImage).withSimilarityThreshold(similarityThreshold);
		return amazonRekognition.compareFaces(compareFacesRequest);
	}

	private static Image getImageUtil(String bucket, String key) {
		return new Image().withS3Object(new S3Object().withBucket(bucket).withName(key));
	}

	private static Image getImageUtilWithBytes(ByteBuffer imageByte) {
		return new Image().withBytes(imageByte);
	}
}
