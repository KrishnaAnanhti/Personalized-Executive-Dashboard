package com.unisys.demo;

import com.amazonaws.services.lambda.runtime.Context; 
import com.amazonaws.services.lambda.runtime.LambdaLogger;

public class FaceCompareTest { 

	public String myHandler(Context context) {
		LambdaLogger logger = context.getLogger();
		logger.log("\nStarting");
		return "working";
	} 
}
